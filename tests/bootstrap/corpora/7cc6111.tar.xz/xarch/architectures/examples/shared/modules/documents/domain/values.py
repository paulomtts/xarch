DocumentId = NewType("DocumentId", UUID)
